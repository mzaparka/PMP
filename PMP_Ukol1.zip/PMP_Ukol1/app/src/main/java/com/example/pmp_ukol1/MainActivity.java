package com.example.pmp_ukol1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editText_MnozstviZbozi1;
    EditText editText_MnozstviZbozi2;
    EditText editText_CenaZbozi1;
    EditText editText_CenaZbozi2;
    TextView textView_Vysledek;
    Spinner spinner_MnozstevniJednotka;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_MnozstviZbozi1 = (EditText) findViewById(R.id.editText_MnozstviZbozi1);
        editText_MnozstviZbozi2 = (EditText) findViewById(R.id.editText_MnozstviZbozi2);
        editText_CenaZbozi1 = (EditText) findViewById(R.id.editText_CenaZbozi1);
        editText_CenaZbozi2 = (EditText) findViewById(R.id.editText_CenaZbozi2);
        textView_Vysledek = (TextView) findViewById(R.id.textView_Vysledek);
        spinner_MnozstevniJednotka = (Spinner) findViewById(R.id.spinner_MnozstevniJednotka);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.quantity_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_MnozstevniJednotka.setAdapter(adapter);
    }

    public void OnClick_ButtonVyhodnotitZbozi(View v) {
        Double cenaZaJednotkuZbozi1 = Double.valueOf(editText_CenaZbozi1.getText().toString()) / Double.valueOf(editText_MnozstviZbozi1.getText().toString());
        Double cenaZaJednotkuZbozi2 = Double.valueOf(editText_CenaZbozi2.getText().toString()) / Double.valueOf(editText_MnozstviZbozi2.getText().toString());
        String textVysledek = "";
        textVysledek += "Cena za " + spinner_MnozstevniJednotka.getSelectedItem().toString() + " prvního zboží: " + cenaZaJednotkuZbozi1;
        textVysledek += "\nCena za " + spinner_MnozstevniJednotka.getSelectedItem().toString() + " druhého zboží: " + cenaZaJednotkuZbozi2;
        if (cenaZaJednotkuZbozi1 > cenaZaJednotkuZbozi2) {
            textVysledek += "\n\nLevnější je druhé zboží.";
        } else if (cenaZaJednotkuZbozi1 < cenaZaJednotkuZbozi2) {
            textVysledek += "\n\nLevnější je první zboží.";
        } else {
            textVysledek += "\n\nZboží 1 a 2 jsou stejně drahé.";
        }
        textView_Vysledek.setText(textVysledek);
    }
}
