package com.example.pmp_ukol2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainMenuActivity extends AppCompatActivity {
    TextView textView_PrihlasenyUzivatel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Intent intent = getIntent();
        User prihlasenyUzivatel = (User) intent.getExtras().getSerializable("PRIHLASENY_UZIVATEL");

        textView_PrihlasenyUzivatel = (TextView)findViewById(R.id.textView_PrihlasenyUzivatel);
        textView_PrihlasenyUzivatel.setText(textView_PrihlasenyUzivatel.getText() + " " + prihlasenyUzivatel.getUserName());
    }

    public void OnClick_ButtonOdhlasit(View v) {
        finish();
    }
}
