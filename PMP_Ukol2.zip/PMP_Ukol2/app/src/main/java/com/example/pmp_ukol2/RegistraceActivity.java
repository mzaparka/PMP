package com.example.pmp_ukol2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegistraceActivity extends AppCompatActivity {
    EditText editText_RegUserName;
    EditText editText_RegPassword1;
    EditText editText_RegPassword2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrace);

        editText_RegUserName = (EditText)findViewById(R.id.editText_RegUserName);
        editText_RegPassword1 = (EditText)findViewById(R.id.editText_RegPassword1);
        editText_RegPassword2 = (EditText)findViewById(R.id.editText_RegPassword2);
    }

    public void OnClick_ButtonRegistraceConfirm(View v) {
        boolean povinnaPoleVyplnena = true;
        if (editText_RegUserName.getText().toString().trim().equals("")) {
            editText_RegUserName.setError("Přihlašovací jméno je povinné.");
            povinnaPoleVyplnena = false;
        }
        if (editText_RegPassword1.getText().toString().trim().equals("")) {
            editText_RegPassword1.setError("Heslo je povinné.");
            povinnaPoleVyplnena = false;
        }
        if (editText_RegPassword2.getText().toString().trim().equals("")) {
            editText_RegPassword2.setError("Ověření hesla je povinné.");
            povinnaPoleVyplnena = false;
        }
        if (!povinnaPoleVyplnena) {
            return;
        }
        if (!editText_RegPassword1.getText().toString().trim().equals(editText_RegPassword2.getText().toString().trim())) {
            Toast.makeText(getApplicationContext(), "Chyba: Heslo a ověření hesla se neshoduje!", Toast.LENGTH_SHORT).show();
            return;
        }

        User novyUzivatel = new User(editText_RegUserName.getText().toString().trim(), editText_RegPassword1.getText().toString().trim());
        MainActivity.list_Users.add(novyUzivatel);
        Toast.makeText(getApplicationContext(), "Registrace proběhla úspěšně!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void OnClick_ButtonBack(View v) {
        finish();
    }
}
