package com.example.pmp_ukol2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText editText_UserName;
    EditText editText_Password;
    public static List<User> list_Users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list_Users = new ArrayList<User>();
        list_Users.add(new User("lukas.tuma", "heslo123"));
        list_Users.add(new User("miroslav.zaparka", "heslo321"));

        editText_UserName = (EditText)findViewById(R.id.editText_UserName);
        editText_Password = (EditText)findViewById(R.id.editText_Password);
    }

    public void OnClick_ButtonLogin(View v) {
        boolean povinnaPoleVyplnena = true;
        if (editText_UserName.getText().toString().trim().equals("")) {
            editText_UserName.setError("Přihlašovací jméno je povinné.");
            povinnaPoleVyplnena = false;
        }
        if (editText_Password.getText().toString().trim().equals("")) {
            editText_Password.setError("Heslo je povinné.");
            povinnaPoleVyplnena = false;
        }
        if (povinnaPoleVyplnena) {
            boolean spravneUdaje = false;
            for (int i = 0; i < list_Users.size(); i++) {
                if (editText_UserName.getText().toString().trim().equals(((User) list_Users.get(i)).getUserName())) {
                    if (editText_Password.getText().toString().trim().equals(((User) list_Users.get(i)).getPassword())) {
                        spravneUdaje = true;
                        Intent intent = new Intent(getApplicationContext(), MainMenuActivity.class);
                        intent.putExtra("PRIHLASENY_UZIVATEL", ((User) list_Users.get(i)));
                        startActivity(intent);

                        editText_UserName.setText("");
                        editText_Password.setText("");
                    }
                }
            }
            if (!spravneUdaje) {
                Toast.makeText(getApplicationContext(), "Chyba: Nesprávné přihlašovací údaje!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void OnClick_Button_Registrace(View v) {
        Intent intent = new Intent(getApplicationContext(), RegistraceActivity.class);
        startActivity(intent);
    }
}
