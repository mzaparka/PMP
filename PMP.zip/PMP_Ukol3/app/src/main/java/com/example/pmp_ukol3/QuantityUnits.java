package com.example.pmp_ukol3;

public enum QuantityUnits {
    kus,
    kilo,
    gram,
    mililitr,
    litr
}
