package com.example.pmp_ukol3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner spinner_SeznamZbozi;
    List<Zbozi> list_Zbozi;
    public static List<VybraneZbozi> list_VybraneZbozi;
    ArrayAdapter zboziAdapter;
    ArrayAdapter zboziVKosikuAdapter;
    ListView listView_GoodsInCart;
    TextView textView_ZboziJizNakoupeno;
    TextView textView_ZboziCelkem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list_Zbozi = new ArrayList<Zbozi>();
        list_VybraneZbozi = new ArrayList<VybraneZbozi>();

        list_Zbozi.add(new Zbozi("rohlík", QuantityUnits.kus, 1.9));
        list_Zbozi.add(new Zbozi("mléko", QuantityUnits.litr, 17));
        list_Zbozi.add(new Zbozi("mouka", QuantityUnits.kilo, 25));
        list_Zbozi.add(new Zbozi("jogurt", QuantityUnits.kus, 9.5));
        list_Zbozi.add(new Zbozi("banány", QuantityUnits.kilo, 35));
        list_Zbozi.add(new Zbozi("pivo", QuantityUnits.kus, 13));
        list_Zbozi.add(new Zbozi("kuře", QuantityUnits.kilo, 80));

        zboziAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, list_Zbozi);

        spinner_SeznamZbozi = (Spinner) findViewById(R.id.spinner_SeznamZbozi);
        spinner_SeznamZbozi.setAdapter(zboziAdapter);

        zboziVKosikuAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, list_VybraneZbozi);

        listView_GoodsInCart = (ListView) findViewById(R.id.listView_GoodsInCart);
        listView_GoodsInCart.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView_GoodsInCart.setAdapter(zboziVKosikuAdapter);

        listView_GoodsInCart.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,long arg3) {
                view.setSelected(true);
                AktualizujSouctyCen();
            }
        });

        textView_ZboziCelkem = (TextView) findViewById(R.id.textView_ZboziCelkem);
        textView_ZboziCelkem.setText(textView_ZboziCelkem.getText().toString() + " 0.0 Kč");
        textView_ZboziJizNakoupeno = (TextView) findViewById(R.id.textView_ZboziJizNakoupeno);
        textView_ZboziJizNakoupeno.setText(textView_ZboziJizNakoupeno.getText().toString() + " 0.0 Kč");
    }

    public void AktualizujSouctyCen() {
        double cenaZboziVKosiku = 0;
        double cenaZboziCelkem = 0;
        for (int i = 0; i < list_VybraneZbozi.size(); i++) {
            VybraneZbozi vz = list_VybraneZbozi.get(i);
            if(listView_GoodsInCart.isItemChecked(i)) {
                cenaZboziVKosiku += (vz.getQuantity() * vz.getPricePerUnit());
            }
            cenaZboziCelkem += (vz.getQuantity() * vz.getPricePerUnit());
        }
        textView_ZboziJizNakoupeno.setText(getResources().getString(R.string.TEXT_CENA_ZBOZI_V_KOSIKU) + " " + cenaZboziVKosiku + " Kč");
        textView_ZboziCelkem.setText(getResources().getString(R.string.TEXT_CELKOVA_CENA_ZBOZI) + " " + cenaZboziCelkem + " Kč");
    }

    public void OnClick_ButtonPridatZbozi(View v) {
        for (int i = 0; i < list_Zbozi.size(); i++) {
            if (spinner_SeznamZbozi.getSelectedItem().toString().trim().equals(((Zbozi) list_Zbozi.get(i)).getName())) {
                Intent intent = new Intent(getApplicationContext(), QuantityActivity.class);
                intent.putExtra("VYBRANE_ZBOZI", ((Zbozi) list_Zbozi.get(i)));
                startActivityForResult(intent, 1);
            }
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        zboziVKosikuAdapter.notifyDataSetChanged();
        AktualizujSouctyCen();
    }
}
