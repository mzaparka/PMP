package com.example.pmp_ukol3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class QuantityActivity extends AppCompatActivity {
    EditText editText_SelectedGoods;
    EditText editText_QuantityUnit;
    EditText editText_Quantity;
    Zbozi vybraneZbozi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quantity);

        editText_SelectedGoods = (EditText)findViewById(R.id.editText_SelectedGoods);
        editText_QuantityUnit = (EditText)findViewById(R.id.editText_QuantityUnit);
        editText_Quantity = (EditText)findViewById(R.id.editText_Quantity);

        Intent intent = getIntent();
        vybraneZbozi = (Zbozi) intent.getExtras().getSerializable("VYBRANE_ZBOZI");

        editText_SelectedGoods.setText(editText_SelectedGoods.getText().toString() + " " + vybraneZbozi.getName());
        editText_QuantityUnit.setText(editText_QuantityUnit.getText().toString() + " " + vybraneZbozi.getQuantityUnit());
    }

    public void OnClick_ButtonAddToCart(View v) {
        VybraneZbozi pridavaneZbozi = new VybraneZbozi(vybraneZbozi.getName(), vybraneZbozi.getQuantityUnit(), vybraneZbozi.getPricePerUnit(), Double.valueOf(editText_Quantity.getText().toString()));
        boolean zboziJizVKosiku = false;
        for (int i = 0; i < MainActivity.list_VybraneZbozi.size(); i++) {
            if (vybraneZbozi.getName().equals(((VybraneZbozi)MainActivity.list_VybraneZbozi.get(i)).getName())) {
                zboziJizVKosiku = true;
                if (!((VybraneZbozi)MainActivity.list_VybraneZbozi.get(i)).pridejOdeberMnozstvi(Double.valueOf(editText_Quantity.getText().toString()))) {
                    MainActivity.list_VybraneZbozi.remove(i);
                }
                break;
            }
        }
        if (!zboziJizVKosiku) {
            MainActivity.list_VybraneZbozi.add(pridavaneZbozi);
        }
        setResult(RESULT_OK, new Intent());
        finish();
    }

    public void OnClick_ButtonBack(View v) {
        finish();
    }
}
