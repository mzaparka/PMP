package com.example.pmp_ukol3;

import java.io.Serializable;

public class Zbozi implements Serializable {
    private String name;
    private QuantityUnits quantityUnit;
    private double princePerUnit;

    Zbozi(String name, QuantityUnits quantityUnit, double princePerUnit) {
        this.name = name;
        this.quantityUnit = quantityUnit;
        this.princePerUnit = princePerUnit;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getName() {
        return name;
    }

    public QuantityUnits getQuantityUnit() {
        return quantityUnit;
    }

    public double getPricePerUnit() {
        return princePerUnit;
    }
}
