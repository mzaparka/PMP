package com.example.pmp_ukol3;

public class VybraneZbozi extends Zbozi {
    private double quantity;

    VybraneZbozi(String name, QuantityUnits quantityUnit, double princePerUnit, double quantity) {
        super(name, quantityUnit, princePerUnit);
        this.quantity = quantity;
    }

    public double getQuantity() {
        return quantity;
    }

    public String toString() {
        return super.getName() + ": " + this.quantity + "x " + super.getQuantityUnit();
    }

    public boolean pridejOdeberMnozstvi(double quantity) {
        this.quantity += quantity;
        return (this.quantity > 0);
    }
}
